/****************************************************************************
** Meta object code from reading C++ file 'controlgui.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../ControlGUI/controlgui.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlgui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ControlGUI_t {
    QByteArrayData data[39];
    char stringdata0[763];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ControlGUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ControlGUI_t qt_meta_stringdata_ControlGUI = {
    {
QT_MOC_LITERAL(0, 0, 10), // "ControlGUI"
QT_MOC_LITERAL(1, 11, 20), // "dagger_button_pushed"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 26), // "giantCleaner_button_pushed"
QT_MOC_LITERAL(4, 60, 17), // "something_toggled"
QT_MOC_LITERAL(5, 78, 16), // "QList<FpgaState>"
QT_MOC_LITERAL(6, 95, 6), // "states"
QT_MOC_LITERAL(7, 102, 21), // "westGateValve_toggled"
QT_MOC_LITERAL(8, 124, 7), // "checked"
QT_MOC_LITERAL(9, 132, 27), // "roundhouseGateValve_toggled"
QT_MOC_LITERAL(10, 160, 18), // "beamEnable_toggled"
QT_MOC_LITERAL(11, 179, 18), // "nedmEnable_toggled"
QT_MOC_LITERAL(12, 198, 15), // "cleaner_toggled"
QT_MOC_LITERAL(13, 214, 22), // "trapdoor_index_changed"
QT_MOC_LITERAL(14, 237, 5), // "index"
QT_MOC_LITERAL(15, 243, 17), // "butterfly_toggled"
QT_MOC_LITERAL(16, 261, 20), // "giantCleaner_toggled"
QT_MOC_LITERAL(17, 282, 16), // "openFile_clicked"
QT_MOC_LITERAL(18, 299, 19), // "startButton_clicked"
QT_MOC_LITERAL(19, 319, 9), // "firstcall"
QT_MOC_LITERAL(20, 329, 13), // "updatePattern"
QT_MOC_LITERAL(21, 343, 17), // "updateElapsedTime"
QT_MOC_LITERAL(22, 361, 19), // "abortButton_clicked"
QT_MOC_LITERAL(23, 381, 18), // "waitForGoThenStart"
QT_MOC_LITERAL(24, 400, 20), // "doNextBeamTransition"
QT_MOC_LITERAL(25, 421, 29), // "doNextWestGateValveTransition"
QT_MOC_LITERAL(26, 451, 35), // "doNextRoundhouseGateValveTran..."
QT_MOC_LITERAL(27, 487, 23), // "doNextCleanerTransition"
QT_MOC_LITERAL(28, 511, 24), // "doNextTrapdoorTransition"
QT_MOC_LITERAL(29, 536, 22), // "doNextDaggerTransition"
QT_MOC_LITERAL(30, 559, 28), // "doNextGiantCleanerTransition"
QT_MOC_LITERAL(31, 588, 25), // "doNextButterflyTransition"
QT_MOC_LITERAL(32, 614, 21), // "doNextnEDMTransistion"
QT_MOC_LITERAL(33, 636, 28), // "doNextPumpOutPortTransistion"
QT_MOC_LITERAL(34, 665, 27), // "doNextSourceCtrlTransistion"
QT_MOC_LITERAL(35, 693, 32), // "on_loadfileNumber_button_clicked"
QT_MOC_LITERAL(36, 726, 9), // "fillCheck"
QT_MOC_LITERAL(37, 736, 20), // "enableChannelButtons"
QT_MOC_LITERAL(38, 757, 5) // "state"

    },
    "ControlGUI\0dagger_button_pushed\0\0"
    "giantCleaner_button_pushed\0something_toggled\0"
    "QList<FpgaState>\0states\0westGateValve_toggled\0"
    "checked\0roundhouseGateValve_toggled\0"
    "beamEnable_toggled\0nedmEnable_toggled\0"
    "cleaner_toggled\0trapdoor_index_changed\0"
    "index\0butterfly_toggled\0giantCleaner_toggled\0"
    "openFile_clicked\0startButton_clicked\0"
    "firstcall\0updatePattern\0updateElapsedTime\0"
    "abortButton_clicked\0waitForGoThenStart\0"
    "doNextBeamTransition\0doNextWestGateValveTransition\0"
    "doNextRoundhouseGateValveTransition\0"
    "doNextCleanerTransition\0"
    "doNextTrapdoorTransition\0"
    "doNextDaggerTransition\0"
    "doNextGiantCleanerTransition\0"
    "doNextButterflyTransition\0"
    "doNextnEDMTransistion\0"
    "doNextPumpOutPortTransistion\0"
    "doNextSourceCtrlTransistion\0"
    "on_loadfileNumber_button_clicked\0"
    "fillCheck\0enableChannelButtons\0state"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ControlGUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      44,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  234,    2, 0x08 /* Private */,
       3,    0,  235,    2, 0x08 /* Private */,
       4,    1,  236,    2, 0x08 /* Private */,
       7,    1,  239,    2, 0x08 /* Private */,
       9,    1,  242,    2, 0x08 /* Private */,
      10,    1,  245,    2, 0x08 /* Private */,
      11,    1,  248,    2, 0x08 /* Private */,
      12,    1,  251,    2, 0x08 /* Private */,
      13,    1,  254,    2, 0x08 /* Private */,
      15,    1,  257,    2, 0x08 /* Private */,
      16,    1,  260,    2, 0x08 /* Private */,
      17,    0,  263,    2, 0x08 /* Private */,
      18,    2,  264,    2, 0x08 /* Private */,
      18,    1,  269,    2, 0x28 /* Private | MethodCloned */,
      18,    0,  272,    2, 0x28 /* Private | MethodCloned */,
      21,    0,  273,    2, 0x08 /* Private */,
      22,    0,  274,    2, 0x08 /* Private */,
      23,    1,  275,    2, 0x08 /* Private */,
      23,    0,  278,    2, 0x28 /* Private | MethodCloned */,
      24,    1,  279,    2, 0x08 /* Private */,
      24,    0,  282,    2, 0x28 /* Private | MethodCloned */,
      25,    1,  283,    2, 0x08 /* Private */,
      25,    0,  286,    2, 0x28 /* Private | MethodCloned */,
      26,    1,  287,    2, 0x08 /* Private */,
      26,    0,  290,    2, 0x28 /* Private | MethodCloned */,
      27,    1,  291,    2, 0x08 /* Private */,
      27,    0,  294,    2, 0x28 /* Private | MethodCloned */,
      28,    1,  295,    2, 0x08 /* Private */,
      28,    0,  298,    2, 0x28 /* Private | MethodCloned */,
      29,    1,  299,    2, 0x08 /* Private */,
      29,    0,  302,    2, 0x28 /* Private | MethodCloned */,
      30,    1,  303,    2, 0x08 /* Private */,
      30,    0,  306,    2, 0x28 /* Private | MethodCloned */,
      31,    1,  307,    2, 0x08 /* Private */,
      31,    0,  310,    2, 0x28 /* Private | MethodCloned */,
      32,    1,  311,    2, 0x08 /* Private */,
      32,    0,  314,    2, 0x28 /* Private | MethodCloned */,
      33,    1,  315,    2, 0x08 /* Private */,
      33,    0,  318,    2, 0x28 /* Private | MethodCloned */,
      34,    1,  319,    2, 0x08 /* Private */,
      34,    0,  322,    2, 0x28 /* Private | MethodCloned */,
      35,    0,  323,    2, 0x08 /* Private */,
      36,    0,  324,    2, 0x08 /* Private */,
      37,    1,  325,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   19,   20,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   38,

       0        // eod
};

void ControlGUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ControlGUI *_t = static_cast<ControlGUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->dagger_button_pushed(); break;
        case 1: _t->giantCleaner_button_pushed(); break;
        case 2: _t->something_toggled((*reinterpret_cast< QList<FpgaState>(*)>(_a[1]))); break;
        case 3: _t->westGateValve_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->roundhouseGateValve_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->beamEnable_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->nedmEnable_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->cleaner_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->trapdoor_index_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->butterfly_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->giantCleaner_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->openFile_clicked(); break;
        case 12: _t->startButton_clicked((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 13: _t->startButton_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->startButton_clicked(); break;
        case 15: _t->updateElapsedTime(); break;
        case 16: _t->abortButton_clicked(); break;
        case 17: _t->waitForGoThenStart((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->waitForGoThenStart(); break;
        case 19: _t->doNextBeamTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->doNextBeamTransition(); break;
        case 21: _t->doNextWestGateValveTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->doNextWestGateValveTransition(); break;
        case 23: _t->doNextRoundhouseGateValveTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->doNextRoundhouseGateValveTransition(); break;
        case 25: _t->doNextCleanerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->doNextCleanerTransition(); break;
        case 27: _t->doNextTrapdoorTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->doNextTrapdoorTransition(); break;
        case 29: _t->doNextDaggerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->doNextDaggerTransition(); break;
        case 31: _t->doNextGiantCleanerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->doNextGiantCleanerTransition(); break;
        case 33: _t->doNextButterflyTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: _t->doNextButterflyTransition(); break;
        case 35: _t->doNextnEDMTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->doNextnEDMTransistion(); break;
        case 37: _t->doNextPumpOutPortTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: _t->doNextPumpOutPortTransistion(); break;
        case 39: _t->doNextSourceCtrlTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 40: _t->doNextSourceCtrlTransistion(); break;
        case 41: _t->on_loadfileNumber_button_clicked(); break;
        case 42: _t->fillCheck(); break;
        case 43: _t->enableChannelButtons((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject ControlGUI::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ControlGUI.data,
      qt_meta_data_ControlGUI,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ControlGUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ControlGUI::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ControlGUI.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int ControlGUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 44)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 44;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 44)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 44;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
