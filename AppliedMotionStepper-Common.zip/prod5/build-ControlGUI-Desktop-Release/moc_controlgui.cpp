/****************************************************************************
** Meta object code from reading C++ file 'controlgui.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../ControlGUI_Eric_DO_NOT_USE/controlgui.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlgui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ControlGUI_t {
    QByteArrayData data[37];
    char stringdata[703];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_ControlGUI_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_ControlGUI_t qt_meta_stringdata_ControlGUI = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 20),
QT_MOC_LITERAL(2, 32, 0),
QT_MOC_LITERAL(3, 33, 26),
QT_MOC_LITERAL(4, 60, 17),
QT_MOC_LITERAL(5, 78, 16),
QT_MOC_LITERAL(6, 95, 6),
QT_MOC_LITERAL(7, 102, 17),
QT_MOC_LITERAL(8, 120, 7),
QT_MOC_LITERAL(9, 128, 18),
QT_MOC_LITERAL(10, 147, 18),
QT_MOC_LITERAL(11, 166, 15),
QT_MOC_LITERAL(12, 182, 22),
QT_MOC_LITERAL(13, 205, 5),
QT_MOC_LITERAL(14, 211, 17),
QT_MOC_LITERAL(15, 229, 16),
QT_MOC_LITERAL(16, 246, 19),
QT_MOC_LITERAL(17, 266, 9),
QT_MOC_LITERAL(18, 276, 13),
QT_MOC_LITERAL(19, 290, 17),
QT_MOC_LITERAL(20, 308, 19),
QT_MOC_LITERAL(21, 328, 18),
QT_MOC_LITERAL(22, 347, 20),
QT_MOC_LITERAL(23, 368, 25),
QT_MOC_LITERAL(24, 394, 23),
QT_MOC_LITERAL(25, 418, 24),
QT_MOC_LITERAL(26, 443, 22),
QT_MOC_LITERAL(27, 466, 28),
QT_MOC_LITERAL(28, 495, 25),
QT_MOC_LITERAL(29, 521, 21),
QT_MOC_LITERAL(30, 543, 28),
QT_MOC_LITERAL(31, 572, 27),
QT_MOC_LITERAL(32, 600, 32),
QT_MOC_LITERAL(33, 633, 9),
QT_MOC_LITERAL(34, 643, 31),
QT_MOC_LITERAL(35, 675, 20),
QT_MOC_LITERAL(36, 696, 5)
    },
    "ControlGUI\0dagger_button_pushed\0\0"
    "giantCleaner_button_pushed\0something_toggled\0"
    "QList<FpgaState>\0states\0gateValve_toggled\0"
    "checked\0beamEnable_toggled\0"
    "nedmEnable_toggled\0cleaner_toggled\0"
    "trapdoor_index_changed\0index\0"
    "butterfly_toggled\0openFile_clicked\0"
    "startButton_clicked\0firstcall\0"
    "updatePattern\0updateElapsedTime\0"
    "abortButton_clicked\0waitForGoThenStart\0"
    "doNextBeamTransition\0doNextGateValveTransition\0"
    "doNextCleanerTransition\0"
    "doNextTrapdoorTransition\0"
    "doNextDaggerTransition\0"
    "doNextGiantCleanerTransition\0"
    "doNextButterflyTransition\0"
    "doNextnEDMTransistion\0"
    "doNextPumpOutPortTransistion\0"
    "doNextSourceCtrlTransistion\0"
    "on_loadfileNumber_button_clicked\0"
    "fillCheck\0on_D2PumpOutradioButton_toggled\0"
    "enableChannelButtons\0state\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ControlGUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      41,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  219,    2, 0x08,
       3,    0,  220,    2, 0x08,
       4,    1,  221,    2, 0x08,
       7,    1,  224,    2, 0x08,
       9,    1,  227,    2, 0x08,
      10,    1,  230,    2, 0x08,
      11,    1,  233,    2, 0x08,
      12,    1,  236,    2, 0x08,
      14,    1,  239,    2, 0x08,
      15,    0,  242,    2, 0x08,
      16,    2,  243,    2, 0x08,
      16,    1,  248,    2, 0x28,
      16,    0,  251,    2, 0x28,
      19,    0,  252,    2, 0x08,
      20,    0,  253,    2, 0x08,
      21,    1,  254,    2, 0x08,
      21,    0,  257,    2, 0x28,
      22,    1,  258,    2, 0x08,
      22,    0,  261,    2, 0x28,
      23,    1,  262,    2, 0x08,
      23,    0,  265,    2, 0x28,
      24,    1,  266,    2, 0x08,
      24,    0,  269,    2, 0x28,
      25,    1,  270,    2, 0x08,
      25,    0,  273,    2, 0x28,
      26,    1,  274,    2, 0x08,
      26,    0,  277,    2, 0x28,
      27,    1,  278,    2, 0x08,
      27,    0,  281,    2, 0x28,
      28,    1,  282,    2, 0x08,
      28,    0,  285,    2, 0x28,
      29,    1,  286,    2, 0x08,
      29,    0,  289,    2, 0x28,
      30,    1,  290,    2, 0x08,
      30,    0,  293,    2, 0x28,
      31,    1,  294,    2, 0x08,
      31,    0,  297,    2, 0x28,
      32,    0,  298,    2, 0x08,
      33,    0,  299,    2, 0x08,
      34,    1,  300,    2, 0x08,
      35,    1,  303,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   17,   18,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,   36,

       0        // eod
};

void ControlGUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ControlGUI *_t = static_cast<ControlGUI *>(_o);
        switch (_id) {
        case 0: _t->dagger_button_pushed(); break;
        case 1: _t->giantCleaner_button_pushed(); break;
        case 2: _t->something_toggled((*reinterpret_cast< QList<FpgaState>(*)>(_a[1]))); break;
        case 3: _t->gateValve_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->beamEnable_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->nedmEnable_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->cleaner_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->trapdoor_index_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->butterfly_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->openFile_clicked(); break;
        case 10: _t->startButton_clicked((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 11: _t->startButton_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->startButton_clicked(); break;
        case 13: _t->updateElapsedTime(); break;
        case 14: _t->abortButton_clicked(); break;
        case 15: _t->waitForGoThenStart((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->waitForGoThenStart(); break;
        case 17: _t->doNextBeamTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->doNextBeamTransition(); break;
        case 19: _t->doNextGateValveTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->doNextGateValveTransition(); break;
        case 21: _t->doNextCleanerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->doNextCleanerTransition(); break;
        case 23: _t->doNextTrapdoorTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->doNextTrapdoorTransition(); break;
        case 25: _t->doNextDaggerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->doNextDaggerTransition(); break;
        case 27: _t->doNextGiantCleanerTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->doNextGiantCleanerTransition(); break;
        case 29: _t->doNextButterflyTransition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->doNextButterflyTransition(); break;
        case 31: _t->doNextnEDMTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->doNextnEDMTransistion(); break;
        case 33: _t->doNextPumpOutPortTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: _t->doNextPumpOutPortTransistion(); break;
        case 35: _t->doNextSourceCtrlTransistion((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->doNextSourceCtrlTransistion(); break;
        case 37: _t->on_loadfileNumber_button_clicked(); break;
        case 38: _t->fillCheck(); break;
        case 39: _t->on_D2PumpOutradioButton_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 40: _t->enableChannelButtons((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject ControlGUI::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ControlGUI.data,
      qt_meta_data_ControlGUI,  qt_static_metacall, 0, 0}
};


const QMetaObject *ControlGUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ControlGUI::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ControlGUI.stringdata))
        return static_cast<void*>(const_cast< ControlGUI*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int ControlGUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 41)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 41;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 41)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 41;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
